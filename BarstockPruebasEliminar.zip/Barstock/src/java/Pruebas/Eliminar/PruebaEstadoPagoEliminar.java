package Pruebas.Eliminar;

import java.util.Scanner;
import Controlador.EstadoPedidoDAO;

public class PruebaEstadoPagoEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EstadoPedidoDAO dao = new EstadoPedidoDAO();

        System.out.println("===== ELIMINAR ESTADO PEDIDO =====");
        System.out.print("Ingrese el ID del estado a eliminar: ");

        int id = sc.nextInt();

        dao.eliminar(id);

        sc.close();
    }
}
