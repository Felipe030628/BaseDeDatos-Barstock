package Pruebas.Insertar;

import Controlador.MovimientoStockDAO;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import modelo.MovimientosStock;

public class PruebaInsertarMovimientoStock {

    public static void main(String[] args) {

        try {
            Scanner sc = new Scanner(System.in);
            MovimientoStockDAO dao = new MovimientoStockDAO();
            MovimientosStock m = new MovimientosStock();

            System.out.print("Ingrese fecha (yyyy-mm-dd): ");
            String fechaTexto = sc.nextLine();
            Date fecha = new SimpleDateFormat("yyyy-MM-dd").parse(fechaTexto);
            m.fecha_movimiento = fecha;

            System.out.print("Ingrese cantidad: ");
            m.cantidad = Integer.parseInt(sc.nextLine());

            System.out.print("Ingrese motivo: ");
            m.motivo = sc.nextLine();

            System.out.print("Ingrese id del producto: ");
            m.productos_idProductos = Integer.parseInt(sc.nextLine());

            dao.insertar(m);

            sc.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}