package Pruebas.Insertar;

import Controlador.SeguimientoPedidoDAO;
import modelo.SeguimientoPedido;

import java.util.Scanner;

public class PruebaInsertarSeguimientoPedido {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Pedimos datos al usuario
        System.out.print("Ingrese id del seguimiento: ");
        int idSeguimiento = sc.nextInt();
        sc.nextLine(); // Limpiar buffer

        System.out.print("Ingrese descripción del seguimiento: ");
        String descripcion = sc.nextLine();

        System.out.print("Ingrese id del estado del pedido: ");
        int estadoId = sc.nextInt();

        System.out.print("Ingrese id del pedido: ");
        int pedidoId = sc.nextInt();

        // Creamos el objeto
        SeguimientoPedido sp = new SeguimientoPedido();
        sp.idSeguimientoPedido = idSeguimiento;
        sp.seguimientoPedidoCol = descripcion;
        sp.estadoPedidoId = estadoId;
        sp.pedidoId = pedidoId;

        // Insertamos usando el DAO
        SeguimientoPedidoDAO dao = new SeguimientoPedidoDAO();
        dao.insertar(sp);

        System.out.println("Registro insertado correctamente.");
    }
}