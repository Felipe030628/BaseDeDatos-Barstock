package modelo;

public class SeguimientoPedido {

    public int idSeguimientoPedido;
    public String seguimientoPedidoCol;
    public int estadoPedidoId;
    public int pedidoId;

    public SeguimientoPedido() {
    }

    public SeguimientoPedido(int id, String seguimiento, int idEstado, int idPedido) {
        idSeguimientoPedido = id;
        seguimientoPedidoCol = seguimiento;
        estadoPedidoId = idEstado;
        pedidoId = idPedido;
    }
}
