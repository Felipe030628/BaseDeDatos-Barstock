package Controlador;

import modelo.TiposDocumentos;
import java.sql.*;

public class TipoDocumentosDAO {

    // INSERTAR
    public void insertar(TiposDocumentos t) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("INSERT INTO tipos_documentos VALUES (" +
                    t.idTipos_documentos + ", '" +
                    t.descripcion_Doc + "', " +
                    t.consecutivo + ", " +
                    t.usuarios_idUsuarios + ")");

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public TiposDocumentos consultar(int id) {

        TiposDocumentos t = new TiposDocumentos();

        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT * FROM tipos_documentos WHERE idTipos_documentos=" + id);

            if (rs.next()) {
                t.idTipos_documentos = rs.getInt("idTipos_documentos");
                t.descripcion_Doc = rs.getString("descripcion_Doc");
                t.consecutivo = rs.getInt("consecutivo");
                t.usuarios_idUsuarios = rs.getInt("usuarios_idUsuarios");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return t;
    }

    // ACTUALIZAR
    public void actualizar(TiposDocumentos t) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("UPDATE tipos_documentos SET " +
                    "descripcion_Doc='" + t.descripcion_Doc + "', " +
                    "consecutivo=" + t.consecutivo + ", " +
                    "usuarios_idUsuarios=" + t.usuarios_idUsuarios +
                    " WHERE idTipos_documentos=" + t.idTipos_documentos);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("DELETE FROM tipos_documentos WHERE idTipos_documentos=" + id);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
