package Pruebas.Insertar ;
        
        
import java.util.Scanner;
import java.sql.Date;
import modelo.Productos;
import Controlador.ProductosDAO;

public class PruebaInsertarProductos{

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Productos p = new Productos();

        System.out.print("ID Producto: ");
        p.idProductos = sc.nextInt();
        sc.nextLine();

        System.out.print("Numero Producto: ");
        p.num_productos = sc.nextLine();

        System.out.print("Descripcion: ");
        p.descripcion = sc.nextLine();

        System.out.print("Precio: ");
        p.precio = sc.nextDouble();

        System.out.print("Stock: ");
        p.stock = sc.nextInt();
        sc.nextLine();

        System.out.print("Fecha vencimiento (YYYY-MM-DD): ");
        String fechaTexto = sc.nextLine();
        p.fecha_vencimiento = Date.valueOf(fechaTexto);

        System.out.print("ID Categoria: ");
        p.categorias_idCategorias = sc.nextInt();

        new ProductosDAO().insertar(p);

        System.out.println("Producto insertado correctamente");

        sc.close();
    }
}