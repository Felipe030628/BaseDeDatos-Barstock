package Pruebas.Eliminar;

import java.util.Scanner;
import Controlador.MetodosPagoDAO;

public class PruebaMetodosDePagoEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();

        System.out.print("Digite el ID del metodo de pago a eliminar: ");
        int id = sc.nextInt();

        dao.eliminar(id);
    }
}
