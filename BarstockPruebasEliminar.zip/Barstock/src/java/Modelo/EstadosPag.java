package modelo;

public class EstadosPag {

    public int idEstados_Pag;
    public String descripcion_EstadoPago;

    public EstadosPag() {
    }

    public EstadosPag(int id, String descripcion) {
        idEstados_Pag = id;
        descripcion_EstadoPago = descripcion;
    }
}
