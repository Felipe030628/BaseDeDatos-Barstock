package Controlador;

import java.sql.*;
import modelo.Categorias;

public class CategoriaDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(Categorias c) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "INSERT INTO categorias (nom_categoria, descripcion) VALUES ('"
                    + c.nom_categoria + "', '"
                    + c.descripcion + "')";

            st.executeUpdate(sql);
            con.close();
            System.out.println("Categoria insertada correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public Categorias consultar(int id) {
        Categorias c = new Categorias();

        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(
                    "SELECT * FROM categorias WHERE idCategorias=" + id);

            if (rs.next()) {
                c.idCategorias = rs.getInt("idCategorias");
                c.nom_categoria = rs.getString("nom_categoria");
                c.descripcion = rs.getString("descripcion");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return c;
    }

    // ACTUALIZAR
    public void actualizar(Categorias c) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "UPDATE categorias SET "
                    + "nom_categoria='" + c.nom_categoria + "', "
                    + "descripcion='" + c.descripcion + "' "
                    + "WHERE idCategorias=" + c.idCategorias;

            st.executeUpdate(sql);
            con.close();
            System.out.println("Categoria actualizada correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            st.executeUpdate("DELETE FROM categorias WHERE idCategorias=" + id);
            con.close();

            System.out.println("Categoria eliminada correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
