package Pruebas.Eliminar;
import java.util.Scanner;
import Controlador.TipoDocumentosDAO;

public class PruebaTipoDeDocumentoEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        TipoDocumentosDAO dao = new TipoDocumentosDAO();

        System.out.print("Digite el ID del tipo de documento a eliminar: ");
        int id = sc.nextInt();

        dao.eliminar(id);
    }
}
