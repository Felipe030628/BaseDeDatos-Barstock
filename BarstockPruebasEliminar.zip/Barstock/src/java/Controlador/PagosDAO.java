package Controlador;

import modelo.Pagos;
import java.sql.*;

public class PagosDAO {

    // INSERTAR
    public void insertar(Pagos p) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("INSERT INTO pagos VALUES (" +
                    p.idPagos + ", " +
                    p.monto + ", " +
                    p.pedido_Cabecera_idPedido + ", " +
                    p.estados_Pag_idEstados_Pag + ", " +
                    p.metodos_Pago_idMetodos_Pago + ")");

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public Pagos consultar(int id) {

        Pagos p = new Pagos();

        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT * FROM pagos WHERE idPagos=" + id);

            if (rs.next()) {
                p.idPagos = rs.getInt("idPagos");
                p.monto = rs.getDouble("monto");
                p.pedido_Cabecera_idPedido = rs.getInt("pedido_Cabecera_idPedido");
                p.estados_Pag_idEstados_Pag = rs.getInt("estados_Pag_idEstados_Pag");
                p.metodos_Pago_idMetodos_Pago = rs.getInt("metodos_Pago_idMetodos_Pago");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return p;
    }

    // ACTUALIZAR
    public void actualizar(Pagos p) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("UPDATE pagos SET " +
                    "monto=" + p.monto + ", " +
                    "pedido_Cabecera_idPedido=" + p.pedido_Cabecera_idPedido + ", " +
                    "estados_Pag_idEstados_Pag=" + p.estados_Pag_idEstados_Pag + ", " +
                    "metodos_Pago_idMetodos_Pago=" + p.metodos_Pago_idMetodos_Pago +
                    " WHERE idPagos=" + p.idPagos);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("DELETE FROM pagos WHERE idPagos=" + id);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
