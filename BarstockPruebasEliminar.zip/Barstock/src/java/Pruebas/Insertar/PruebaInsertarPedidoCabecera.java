package Pruebas.Insertar;


import java.util.Scanner;
import java.sql.Timestamp;
import modelo.PedidoCabecera;
import Controlador.PedidoCabeceraDAO;

public class PruebaInsertarPedidoCabecera {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PedidoCabecera p = new PedidoCabecera();

        System.out.print("ID Pedido: ");
        p.idPedido = sc.nextInt();
        sc.nextLine();

        System.out.print("Fecha y hora (YYYY-MM-DD HH:MM:SS): ");
        String fechaTexto = sc.nextLine();
        p.fecha_hora = Timestamp.valueOf(fechaTexto);

        System.out.print("ID Usuario: ");
        p.usuarios_idUsuarios = sc.nextInt();
        sc.nextLine();

        System.out.print("ID Mesa: ");
        p.mesa_idMesa = sc.nextLine();  // ES String, no int

        new PedidoCabeceraDAO().insertar(p);

        System.out.println("Insertado correctamente");
        sc.close();
    }
}