package modelo;

public class Usuarios {

    public int idUsuarios;
    public String nombre;
    public String email;
    public String tel;

    public Usuarios() {
    }

    public Usuarios(int id, String nom, String mail, String telefono) {
        idUsuarios = id;
        nombre = nom;
        email = mail;
        tel = telefono;
    }
}
