package modelo;

public class EstadoPedido {

    public int idEstado_Pedido;
    public String estado_pedidoCol;

    public EstadoPedido() {
    }

    public EstadoPedido(int id, String estado) {
        idEstado_Pedido = id;
        estado_pedidoCol = estado;
    }
}
