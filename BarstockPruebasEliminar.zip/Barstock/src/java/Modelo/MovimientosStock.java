package modelo;

import java.util.Date;

public class MovimientosStock {

    public int idMovimientos_stock;
    public Date fecha_movimiento;
    public int cantidad;
    public String motivo;
    public int productos_idProductos;

    public MovimientosStock() {
    }

    public MovimientosStock(int id, Date fecha, int cant, String mot, int idProducto) {
        idMovimientos_stock = id;
        fecha_movimiento = fecha;
        cantidad = cant;
        motivo = mot;
        productos_idProductos = idProducto;
    }
}