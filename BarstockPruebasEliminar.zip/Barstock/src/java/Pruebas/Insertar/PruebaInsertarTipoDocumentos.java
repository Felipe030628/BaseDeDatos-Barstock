package Pruebas.Insertar;

import Controlador.TipoDocumentosDAO;
import modelo.TiposDocumentos;
import java.util.Scanner;

public class PruebaInsertarTipoDocumentos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese ID del tipo de documento: ");
        int id = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Ingrese descripción: ");
        String descripcion = sc.nextLine();

        System.out.print("Ingrese consecutivo: ");
        int consecutivo = sc.nextInt();

        System.out.print("Ingrese ID del usuario: ");
        int idUsuario = sc.nextInt();

        // Crear objeto modelo
        TiposDocumentos t = new TiposDocumentos();
        t.idTipos_documentos = id;
        t.descripcion_Doc = descripcion;
        t.consecutivo = consecutivo;
        t.usuarios_idUsuarios = idUsuario;

        // Llamar DAO
        TipoDocumentosDAO dao = new TipoDocumentosDAO();
        dao.insertar(t);

        System.out.println("✅ Registro insertado (si no hubo errores arriba).");

        sc.close();
    }
}