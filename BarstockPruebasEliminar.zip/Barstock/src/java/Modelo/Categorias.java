package modelo;

public class Categorias {

    public int idCategorias;
    public String nom_categoria;
    public String descripcion;

    public Categorias() {
    }

    public Categorias(String nom_categoria, String descripcion) {
        nom_categoria = nom_categoria;
        descripcion = descripcion;
    }
}
