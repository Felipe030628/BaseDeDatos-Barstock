package Pruebas.Eliminar;
import java.util.Scanner;
import Controlador.UsuariosDAO;

public class PruebaUsuariosEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        UsuariosDAO dao = new UsuariosDAO();

        System.out.print("Digite el ID del usuario a eliminar: ");
        int id = sc.nextInt();

        dao.eliminar(id);
    }
}
