package Controlador;

import modelo.Usuarios;
import java.sql.*;

public class UsuariosDAO {

    // INSERTAR
    public void insertar(Usuarios u) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("INSERT INTO usuarios VALUES (" +
                    u.idUsuarios + ", '" +
                    u.nombre + "', '" +
                    u.email + "', '" +
                    u.tel + "')");

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public Usuarios consultar(int id) {

        Usuarios u = new Usuarios();

        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT * FROM usuarios WHERE idUsuarios=" + id);

            if (rs.next()) {
                u.idUsuarios = rs.getInt("idUsuarios");
                u.nombre = rs.getString("nombre");
                u.email = rs.getString("email");
                u.tel = rs.getString("tel");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return u;
    }

    // ACTUALIZAR
    public void actualizar(Usuarios u) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("UPDATE usuarios SET " +
                    "nombre='" + u.nombre + "', " +
                    "email='" + u.email + "', " +
                    "tel='" + u.tel + "'" +
                    " WHERE idUsuarios=" + u.idUsuarios);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("DELETE FROM usuarios WHERE idUsuarios=" + id);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
