package Controlador;

import java.sql.*;
import modelo.MetodosPago;

public class MetodosPagoDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(MetodosPago m) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "INSERT INTO metodos_pago (descripcion_Metodo) VALUES ('"
                    + m.descripcion_Metodo + "')";

            st.executeUpdate(sql);
            con.close();

            System.out.println("Metodo de pago insertado correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public MetodosPago consultar(int id) {
        MetodosPago m = new MetodosPago();

        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(
                    "SELECT * FROM metodos_pago WHERE idMetodos_Pago=" + id);

            if (rs.next()) {
                m.idMetodos_Pago = rs.getInt("idMetodos_Pago");
                m.descripcion_Metodo = rs.getString("descripcion_Metodo");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return m;
    }

    // ACTUALIZAR
    public void actualizar(MetodosPago m) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "UPDATE metodos_pago SET "
                    + "descripcion_Metodo='" + m.descripcion_Metodo + "' "
                    + "WHERE idMetodos_Pago=" + m.idMetodos_Pago;

            st.executeUpdate(sql);
            con.close();

            System.out.println("Metodo de pago actualizado correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            st.executeUpdate("DELETE FROM metodos_pago WHERE idMetodos_Pago=" + id);
            con.close();

            System.out.println("Metodo de pago eliminado correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
