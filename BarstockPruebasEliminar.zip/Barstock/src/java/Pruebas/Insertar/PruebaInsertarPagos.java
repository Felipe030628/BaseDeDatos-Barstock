package Pruebas.Insertar;

import Controlador.PagosDAO;
import java.util.Scanner;
import modelo.Pagos;

public class PruebaInsertarPagos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();
        Pagos p = new Pagos();

        System.out.print("Ingrese idPagos: ");
        p.idPagos = Integer.parseInt(sc.nextLine());

        System.out.print("Ingrese monto: ");
        p.monto = Double.parseDouble(sc.nextLine());

        System.out.print("Ingrese idPedido: ");
        p.pedido_Cabecera_idPedido = Integer.parseInt(sc.nextLine());

        System.out.print("Ingrese idEstadoPago: ");
        p.estados_Pag_idEstados_Pag = Integer.parseInt(sc.nextLine());

        System.out.print("Ingrese idMetodoPago: ");
        p.metodos_Pago_idMetodos_Pago = Integer.parseInt(sc.nextLine());

        dao.insertar(p);

        sc.close();
    }
}