package modelo;

public class Mesa {
    public int idMesa;
    public int cod_mesa;
    public String num_mesa;
}
