package Pruebas.Insertar;

import Controlador.EstadoPedidoDAO;
import java.util.Scanner;
import modelo.EstadoPedido;

public class PruebaInsertarEstadoPedido {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        EstadoPedidoDAO dao = new EstadoPedidoDAO();
        EstadoPedido e = new EstadoPedido();

        System.out.println("=== INSERTAR ESTADO PEDIDO ===");

        System.out.print("Ingrese el estado del pedido: ");
        e.estado_pedidoCol = sc.nextLine();

        dao.insertar(e);

        sc.close();
    }
}