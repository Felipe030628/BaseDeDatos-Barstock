package Pruebas.Insertar;

import Controlador.CategoriaDAO;
import java.util.Scanner;
import modelo.Categorias;

public class PruebaInsertarCategoria {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        CategoriaDAO dao = new CategoriaDAO();
        Categorias c = new Categorias();

        System.out.println("=== INSERTAR CATEGORIA ===");

        System.out.print("Ingrese nombre de la categoria: ");
        c.nom_categoria = sc.nextLine();

        System.out.print("Ingrese descripcion: ");
        c.descripcion = sc.nextLine();

        dao.insertar(c);

        sc.close();
    }
}