package modelo;

public class TiposDocumentos {

    public int idTipos_documentos;
    public String descripcion_Doc;
    public int consecutivo;
    public int usuarios_idUsuarios;

    public TiposDocumentos() {
    }

    public TiposDocumentos(int id, String descripcion, int consec, int idUsuario) {
        idTipos_documentos = id;
        descripcion_Doc = descripcion;
        consecutivo = consec;
        usuarios_idUsuarios = idUsuario;
    }
}
