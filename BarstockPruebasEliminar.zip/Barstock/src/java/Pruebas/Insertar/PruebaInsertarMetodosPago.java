package Pruebas.Insertar;

import Controlador.MetodosPagoDAO;
import java.util.Scanner;
import modelo.MetodosPago;

public class PruebaInsertarMetodosPago {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();
        MetodosPago m = new MetodosPago();

        System.out.print("Ingrese descripcion del metodo de pago: ");
        m.descripcion_Metodo = sc.nextLine();

        dao.insertar(m);

        sc.close();
    }
}