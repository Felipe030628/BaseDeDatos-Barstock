package Controlador;

import java.sql.*;
import modelo.Mesa;

public class MesaDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(Mesa m) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "INSERT INTO mesa (idMesa, cod_mesa, num_mesa) VALUES ('"
                    + m.idMesa + "', "
                    + m.cod_mesa + ", '"
                    + m.num_mesa + "')";

            st.executeUpdate(sql);
            con.close();

            System.out.println("Mesa insertada correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public Mesa consultar(String id) {
        Mesa m = new Mesa();

        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(
                    "SELECT * FROM mesa WHERE idMesa='" + id + "'");

            if (rs.next()) {
                m.idMesa = rs.getInt("idMesa");
                m.cod_mesa = rs.getInt("cod_mesa");
                m.num_mesa = rs.getString("num_mesa");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return m;
    }

    // ACTUALIZAR
    public void actualizar(Mesa m) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "UPDATE mesa SET "
                    + "cod_mesa=" + m.cod_mesa + ", "
                    + "num_mesa='" + m.num_mesa + "' "
                    + "WHERE idMesa='" + m.idMesa + "'";

            st.executeUpdate(sql);
            con.close();

            System.out.println("Mesa actualizada correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(String id) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            st.executeUpdate("DELETE FROM mesa WHERE idMesa='" + id + "'");
            con.close();

            System.out.println("Mesa eliminada correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
