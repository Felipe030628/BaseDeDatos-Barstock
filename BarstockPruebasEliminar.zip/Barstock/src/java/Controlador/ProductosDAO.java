package Controlador;

import modelo.Productos;
import java.sql.*;

public class ProductosDAO {

    // INSERTAR
    public void insertar(Productos p) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("INSERT INTO productos VALUES (" +
                    p.idProductos + ", '" +
                    p.num_productos + "', '" +
                    p.descripcion + "', " +
                    p.precio + ", " +
                    p.stock + ", '" +
                    new java.sql.Date(p.fecha_vencimiento.getTime()) + "', " +
                    p.categorias_idCategorias + ")");

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public Productos consultar(int id) {

        Productos p = new Productos();

        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT * FROM productos WHERE idProductos=" + id);

            if (rs.next()) {
                p.idProductos = rs.getInt("idProductos");
                p.num_productos = rs.getString("num_productos");
                p.descripcion = rs.getString("descripcion");
                p.precio = rs.getDouble("precio");
                p.stock = rs.getInt("stock");
                p.fecha_vencimiento = rs.getDate("fecha_vencimiento");
                p.categorias_idCategorias = rs.getInt("categorias_idCategorias");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return p;
    }

    // ACTUALIZAR
    public void actualizar(Productos p) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("UPDATE productos SET " +
                    "num_productos='" + p.num_productos + "', " +
                    "descripcion='" + p.descripcion + "', " +
                    "precio=" + p.precio + ", " +
                    "stock=" + p.stock + ", " +
                    "fecha_vencimiento='" + new java.sql.Date(p.fecha_vencimiento.getTime()) + "', " +
                    "categorias_idCategorias=" + p.categorias_idCategorias +
                    " WHERE idProductos=" + p.idProductos);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("DELETE FROM productos WHERE idProductos=" + id);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
