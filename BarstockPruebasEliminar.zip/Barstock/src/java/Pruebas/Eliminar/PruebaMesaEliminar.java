package Pruebas.Eliminar;

import java.util.Scanner;
import Controlador.MesaDAO;

public class PruebaMesaEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MesaDAO dao = new MesaDAO();

        System.out.print("ID a eliminar: ");
        String id = sc.nextLine();

        dao.eliminar(id);
    }
}