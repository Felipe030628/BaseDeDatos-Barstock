package Pruebas.Insertar;

import Controlador.MesaDAO;
import java.util.Scanner;
import modelo.Mesa;

public class PruebaInsertarMesa {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MesaDAO dao = new MesaDAO();
        Mesa m = new Mesa();

        System.out.print("Ingrese idMesa (numero): ");
        m.idMesa = Integer.parseInt(sc.nextLine());

        System.out.print("Ingrese cod_mesa (numero): ");
        m.cod_mesa = Integer.parseInt(sc.nextLine());

        System.out.print("Ingrese num_mesa (texto): ");
        m.num_mesa = sc.nextLine();

        dao.insertar(m);
    }
}