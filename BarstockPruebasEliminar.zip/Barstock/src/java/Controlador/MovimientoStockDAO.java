package Controlador;

import java.sql.*;
import modelo.MovimientosStock;

public class MovimientoStockDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(MovimientosStock m) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);

            String sql = "INSERT INTO movimientos_stock "
                    + "(fecha_movimiento, cantidad, motivo, productos_idProductos) "
                    + "VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setDate(1, new java.sql.Date(m.fecha_movimiento.getTime()));
            ps.setInt(2, m.cantidad);
            ps.setString(3, m.motivo);
            ps.setInt(4, m.productos_idProductos);

            ps.executeUpdate();
            con.close();

            System.out.println("Movimiento insertado correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public MovimientosStock consultar(int id) {
        MovimientosStock m = new MovimientosStock();

        try {
            Connection con = DriverManager.getConnection(url, user, pass);

            String sql = "SELECT * FROM movimientos_stock WHERE idMovimientos_stock=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                m.idMovimientos_stock = rs.getInt("idMovimientos_stock");
                m.fecha_movimiento = rs.getDate("fecha_movimiento");
                m.cantidad = rs.getInt("cantidad");
                m.motivo = rs.getString("motivo");
                m.productos_idProductos = rs.getInt("productos_idProductos");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return m;
    }

    // ACTUALIZAR
    public void actualizar(MovimientosStock m) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);

            String sql = "UPDATE movimientos_stock SET "
                    + "fecha_movimiento=?, cantidad=?, motivo=?, productos_idProductos=? "
                    + "WHERE idMovimientos_stock=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setDate(1, new java.sql.Date(m.fecha_movimiento.getTime()));
            ps.setInt(2, m.cantidad);
            ps.setString(3, m.motivo);
            ps.setInt(4, m.productos_idProductos);
            ps.setInt(5, m.idMovimientos_stock);

            ps.executeUpdate();
            con.close();

            System.out.println("Movimiento actualizado correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);

            String sql = "DELETE FROM movimientos_stock WHERE idMovimientos_stock=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            ps.executeUpdate();
            con.close();

            System.out.println("Movimiento eliminado correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
