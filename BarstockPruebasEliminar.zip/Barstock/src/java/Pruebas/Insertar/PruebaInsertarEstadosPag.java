package Pruebas.Insertar;

import Controlador.EstadosPagDAO;
import java.util.Scanner;
import modelo.EstadosPag;

public class PruebaInsertarEstadosPag {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        EstadosPagDAO dao = new EstadosPagDAO();
        EstadosPag e = new EstadosPag();

        System.out.println("=== INSERTAR ESTADO DE PAGO ===");

        System.out.print("Ingrese la descripcion del estado de pago: ");
        e.descripcion_EstadoPago = sc.nextLine();

        dao.insertar(e);

        sc.close();
    }
}