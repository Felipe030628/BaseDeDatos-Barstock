package Controlador;

import java.sql.*;
import modelo.EstadosPag;

public class EstadosPagDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(EstadosPag e) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "INSERT INTO estados_pag (descripcion_EstadoPago) VALUES ('"
                    + e.descripcion_EstadoPago + "')";

            st.executeUpdate(sql);
            con.close();

            System.out.println("Estado de pago insertado correctamente");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // CONSULTAR
    public EstadosPag consultar(int id) {
        EstadosPag e = new EstadosPag();

        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(
                    "SELECT * FROM estados_pag WHERE idEstados_Pag=" + id);

            if (rs.next()) {
                e.idEstados_Pag = rs.getInt("idEstados_Pag");
                e.descripcion_EstadoPago = rs.getString("descripcion_EstadoPago");
            }

            con.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return e;
    }

    // ACTUALIZAR
    public void actualizar(EstadosPag e) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "UPDATE estados_pag SET "
                    + "descripcion_EstadoPago='" + e.descripcion_EstadoPago + "' "
                    + "WHERE idEstados_Pag=" + e.idEstados_Pag;

            st.executeUpdate(sql);
            con.close();

            System.out.println("Estado de pago actualizado correctamente");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            st.executeUpdate("DELETE FROM estados_pag WHERE idEstados_Pag=" + id);
            con.close();

            System.out.println("Estado de pago eliminado correctamente");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
