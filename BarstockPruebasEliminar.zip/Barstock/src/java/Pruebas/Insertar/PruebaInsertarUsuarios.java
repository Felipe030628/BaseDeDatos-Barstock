package Pruebas.Insertar;

import Controlador.UsuariosDAO;
import modelo.Usuarios;
import java.util.Scanner;

public class PruebaInsertarUsuarios {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese ID del usuario: ");
        int id = sc.nextInt();
        sc.nextLine(); // limpiar buffer

        System.out.print("Ingrese nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese email: ");
        String email = sc.nextLine();

        System.out.print("Ingrese teléfono: ");
        String tel = sc.nextLine();

        // Crear objeto modelo
        Usuarios u = new Usuarios();
        u.idUsuarios = id;
        u.nombre = nombre;
        u.email = email;
        u.tel = tel;

        // Llamar DAO
        UsuariosDAO dao = new UsuariosDAO();
        dao.insertar(u);

        System.out.println("✅ Usuario insertado (si no hubo errores arriba).");

        sc.close();
    }
}