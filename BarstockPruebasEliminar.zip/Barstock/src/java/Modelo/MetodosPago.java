package modelo;

public class MetodosPago {

    public int idMetodos_Pago;
    public String descripcion_Metodo;

    public MetodosPago() {
    }

    public MetodosPago(int id, String descripcion) {
        idMetodos_Pago = id;
        descripcion_Metodo = descripcion;
    }
}
