package Controlador;

import java.sql.*;
import modelo.EstadoPedido;

public class EstadoPedidoDAO {

    private String url = "jdbc:mysql://localhost:3307/barstock";
    private String user = "root";
    private String pass = "";

    // INSERTAR
    public void insertar(EstadoPedido e) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "INSERT INTO estado_pedido (estado_pedidoCol) VALUES ('"
                    + e.estado_pedidoCol + "')";

            st.executeUpdate(sql);
            con.close();

            System.out.println("Estado insertado correctamente");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // CONSULTAR
    public EstadoPedido consultar(int id) {
        EstadoPedido e = new EstadoPedido();

        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(
                    "SELECT * FROM estado_pedido WHERE idEstado_Pedido=" + id);

            if (rs.next()) {
                e.idEstado_Pedido = rs.getInt("idEstado_Pedido");
                e.estado_pedidoCol = rs.getString("estado_pedidoCol");
            }

            con.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return e;
    }

    // ACTUALIZAR
    public void actualizar(EstadoPedido e) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            String sql = "UPDATE estado_pedido SET "
                    + "estado_pedidoCol='" + e.estado_pedidoCol + "' "
                    + "WHERE idEstado_Pedido=" + e.idEstado_Pedido;

            st.executeUpdate(sql);
            con.close();

            System.out.println("Estado actualizado correctamente");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();

            st.executeUpdate("DELETE FROM estado_pedido WHERE idEstado_Pedido=" + id);
            con.close();

            System.out.println("Estado eliminado correctamente");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
