package Pruebas.Eliminar;
import java.util.Scanner;
import Controlador.ProductosDAO;

public class PruebaProductosEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();

        System.out.print("Digite el ID del producto a eliminar: ");
        int id = sc.nextInt();

        dao.eliminar(id);
    }
}
