package Controlador;

import modelo.SeguimientoPedido;
import java.sql.*;

public class SeguimientoPedidoDAO {

    // INSERTAR
    public void insertar(SeguimientoPedido s) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("INSERT INTO seguimientopedido VALUES (" +
                    s.idSeguimientoPedido + ", '" +
                    s.seguimientoPedidoCol + "', " +
                    s.estadoPedidoId + ", " +
                    s.pedidoId + ")");

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public SeguimientoPedido consultar(int id) {

        SeguimientoPedido s = new SeguimientoPedido();

        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT * FROM seguimiento_pedido WHERE idSeguimientoPedido=" + id);

            if (rs.next()) {
                s.idSeguimientoPedido = rs.getInt("idSeguimientoPedido");
                s.seguimientoPedidoCol = rs.getString("seguimientoPedidoCol");
                s.estadoPedidoId = rs.getInt("estadoPedidoId");
                s.pedidoId = rs.getInt("pedidoId");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return s;
    }

    // ACTUALIZAR
    public void actualizar(SeguimientoPedido s) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("UPDATE seguimiento_pedido SET " +
                    "seguimientoPedidoCol='" + s.seguimientoPedidoCol + "', " +
                    "estadoPedidoId=" + s.estadoPedidoId + ", " +
                    "pedidoId=" + s.pedidoId +
                    " WHERE idSeguimientoPedido=" + s.idSeguimientoPedido);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("DELETE FROM seguimiento_pedido WHERE idSeguimientoPedido=" + id);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
