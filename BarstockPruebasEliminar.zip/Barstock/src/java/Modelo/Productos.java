package modelo;

import java.util.Date;

public class Productos {

    public int idProductos;
    public String num_productos;
    public String descripcion;
    public double precio;
    public int stock;
    public Date fecha_vencimiento;
    public int categorias_idCategorias;

    public Productos() {
    }

    public Productos(int id, String num, String desc, double pre, int st, Date fecha, int idCategoria) {
        idProductos = id;
        num_productos = num;
        descripcion = desc;
        precio = pre;
        stock = st;
        fecha_vencimiento = fecha;
        categorias_idCategorias = idCategoria;
    }
}
