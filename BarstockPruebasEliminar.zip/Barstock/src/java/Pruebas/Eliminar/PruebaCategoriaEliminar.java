package Pruebas.Eliminar;

import java.util.Scanner;
import Controlador.CategoriaDAO;

public class PruebaCategoriaEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        CategoriaDAO dao = new CategoriaDAO();

        System.out.println("===== ELIMINAR CATEGORIA =====");
        System.out.print("Ingrese el ID de la categoria a eliminar: ");

        int id = sc.nextInt();

        dao.eliminar(id);

        sc.close();
    }
}
