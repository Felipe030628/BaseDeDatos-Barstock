package Pruebas.Eliminar;
import java.util.Scanner;
import Controlador.SeguimientoPedidoDAO;

public class PruebaSeguimientoPedidoEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        SeguimientoPedidoDAO dao = new SeguimientoPedidoDAO();

        System.out.print("Digite el ID del seguimiento a eliminar: ");
        int id = sc.nextInt();

        dao.eliminar(id);
    }
}

