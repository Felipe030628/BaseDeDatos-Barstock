package Pruebas.Eliminar;
import java.util.Scanner;
import Controlador.PedidoCabeceraDAO;

public class PruebaPedidoCabeceraEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PedidoCabeceraDAO dao = new PedidoCabeceraDAO();

        System.out.print("Digite el ID del pedido a eliminar: ");
        int id = sc.nextInt();

        dao.eliminar(id);
    }
}
