package Pruebas.Eliminar;
import java.util.Scanner;
import Controlador.PagosDAO;

public class PruebaPagosEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();

        System.out.print("Digite el ID del pago a eliminar: ");
        int id = sc.nextInt();

        dao.eliminar(id);
    }
}
