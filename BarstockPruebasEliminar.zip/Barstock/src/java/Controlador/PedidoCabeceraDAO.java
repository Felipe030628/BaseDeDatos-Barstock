package Controlador;

import modelo.PedidoCabecera;
import java.sql.*;

public class PedidoCabeceraDAO {

    // INSERTAR
    public void insertar(PedidoCabecera p) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("INSERT INTO pedido_cabecera VALUES (" +
                    p.idPedido + ", '" +
                    p.fecha_hora + "', " +
                    p.usuarios_idUsuarios + ", '" +
                    p.mesa_idMesa + "')");

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CONSULTAR
    public PedidoCabecera consultar(int id) {

        PedidoCabecera p = new PedidoCabecera();

        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(
                    "SELECT * FROM pedido_cabecera WHERE idPedido=" + id);

            if (rs.next()) {
                p.idPedido = rs.getInt("idPedido");
                p.fecha_hora = rs.getTimestamp("fecha_hora");
                p.usuarios_idUsuarios = rs.getInt("usuarios_idUsuarios");
                p.mesa_idMesa = rs.getString("mesa_idMesa");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return p;
    }

    // ACTUALIZAR
    public void actualizar(PedidoCabecera p) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("UPDATE pedido_cabecera SET " +
                    "fecha_hora='" + p.fecha_hora + "', " +
                    "usuarios_idUsuarios=" + p.usuarios_idUsuarios + ", " +
                    "mesa_idMesa='" + p.mesa_idMesa + "'" +
                    " WHERE idPedido=" + p.idPedido);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminar(int id) {
        try {
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/barstock", "root", ""
            );

            Statement st = con.createStatement();
            st.execute("DELETE FROM pedido_cabecera WHERE idPedido=" + id);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
