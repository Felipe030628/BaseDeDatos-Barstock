package Pruebas.Eliminar;

import java.util.Scanner;
import Controlador.EstadosPagDAO;

public class PruebaEstagoPagEliminar {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EstadosPagDAO dao = new EstadosPagDAO();

        System.out.println("===== ELIMINAR ESTADO DE PAGO =====");
        System.out.print("Ingrese el ID del estado de pago a eliminar: ");

        int id = sc.nextInt();

        dao.eliminar(id);

        sc.close();
    }
}

